# Juice KC — Shopify theme handoff

Paste this into Claude Code at the start of a session so it has full context.

---

## The project

Custom Shopify **Online Store 2.0** theme for **Juice KC**, a Kansas City
cold-pressed organic juice business. Sells direct-to-consumer in small runs
and wholesale by the case. Repo: `github.com/youhave3eyes/juicekc`.

## Design direction

- **Look:** Fruit World Co (fruitworldco.com) — warm, family-farm, photography-led,
  soft pink field colour. NOT sleek/minimal, NOT aggressive/streetwear.
- **Palette:** pink `#EF5B8C`, deep pink `#D8447A`, blush `#FDE8EE`,
  cream paper `#FFF9F5`, plum-ink text `#3A2430`, citrus `#F5943D`, leaf `#7FB45F`.
  Never pure black; text is warm plum.
- **Type:** `Lilita One` for all display (headings, buttons, chips, wordmark,
  numerals) — single weight, so vary size and tracking, never weight.
  `Karla` for body copy.
- **Characters:** licensed Adobe Stock retro cartoon fruit (asset `800352289`),
  extracted as inline SVG snippets. 1930s rubber-hose style — noodle limbs,
  gloved hands, chunky shoes.

## Stack facts

- Liquid + JSON templates, no build step, no npm dependencies.
- All CSS in `assets/base.css` (~40KB, single file, mobile-first).
- All JS in `assets/juice.js` (vanilla, no framework, IIFE, no bundler).
- Fonts load from Google Fonts in `layout/theme.liquid`.

## File map

```
layout/theme.liquid            wraps every page; loads fonts, CSS, JS
templates/*.json               which sections render on each page type
sections/                      16 sections, each with a {% schema %}
snippets/fruit-shape.liquid    dispatcher: maps a fruit name to a character
snippets/fruit-<name>.liquid   7 licensed characters as inline SVG
assets/base.css                everything visual
assets/juice.js                all behaviour
config/settings_schema.json    theme editor global settings
```

## Custom sections

| Section | Purpose |
|---|---|
| `hero-flavor` | Photo hero + flavor switcher that recolours the whole site |
| `harvest` | Pink field of fruit cards (Fruit World's signature block) |
| `split` | Photo + text, optional checklist, flippable, optional blush bg |
| `energy` | Electrolytes/energy explainer with two animated SVG curves |
| `batch-calculator` | 5–50 bottle slider, five price tiers, colour shifts per tier |
| `sourcing` | Where the fruit comes from (dark section) |
| `ticker` | Scrolling marquee |
| `flying-mascot` | Watermelon that flies around; catch-3-times reward |

Homepage order: hero → ticker → harvest → buyers(split) → energy → batch →
story(split) → sourcing.

## Behaviours in juice.js

- `initMenu` — mobile drawer, focus trap, Escape to close, closes on link tap
- `initFlavors` / `applyTheme` / `restoreTheme` — flavor picker sets `--theme`
  on `:root`, persists in sessionStorage, updates the `theme-color` meta tag
- `initFruitScroll` — fruit drift on scroll (alternating directions, sine drift,
  depth-scaled rotation); cursor adds a small nudge on `pointer: fine` only
- `initSquish` — tap a fruit, it reacts
- `initFly` — mascot flight paths, greeting bubble, catch tracking
- `initReward` — reward modal, copy-to-clipboard
- `initBatch` — five-tier pricing, colour transitions, track fill, price pips
- `initVariant`, `initCart` — product page basics

## Rules that matter

1. **Fruit characters are homepage-only.** Deliberately removed from footer,
   mobile drawer, and product cards. Don't reintroduce them site-wide.
   The flying mascot IS site-wide — that's intentional.
2. **Mobile first.** Base styles are phone styles; `@media (min-width: 700px)`
   is the enhancement. Tap targets ≥44px, inputs ≥16px font (stops iOS zoom),
   `svh` units, `env(safe-area-inset-*)` on nav and footer.
3. **Character animation runs on `steps()`**, not smooth easing — that stepped
   cadence is what makes it read as vintage film. Don't smooth it out.
4. Each hero fruit has its own routine via `:nth-child` (walk, wave, lean,
   twirl, bounce, cheer) on different cycle lengths so they never sync.
5. **Never touch checkout.** Shop Pay works automatically via Shopify Payments.
6. `prefers-reduced-motion` must disable all of it, including the mascot.
7. Section blocks defined only in `presets` do NOT appear when the section is
   declared in a JSON template — blocks must be written into
   `templates/index.json` explicitly. This bit us once already.

## Known open items

- **Hero needs a background photo.** It's a flat pink field until one is added
  in the theme editor. Fruit World's warmth is mostly photography.
- **Harvest cards accept cutout PNGs** and fall back to illustrations.
  Real cutout product photos would land the look properly.
- **Batch pricing has non-monotonic totals.** 8 bottles = $56 but 9 = $54;
  32 = $192 but 33 = $165. Either soften the tiers or market it as a feature.
  Prices are all editable in the theme editor.
- **Catch reward needs a real discount code.** Create it in Shopify Discounts
  (5% off, one use per customer), then paste the code into the Flying mascot
  section settings. The theme only surfaces a code, it doesn't create one.
- Licensed set has no orange, lemon, beet, mint, or grapes. Those names still
  work in settings but map to the nearest available character.

## Validate before committing

```bash
# section schemas and templates must be valid JSON or the theme won't upload
python3 - <<'EOF'
import re, glob, json
for p in glob.glob('sections/*.liquid'):
    json.loads(re.search(r'\{%\s*schema\s*%\}(.*?)\{%\s*endschema\s*%\}',
               open(p).read(), re.S).group(1))
for p in glob.glob('templates/*.json') + glob.glob('config/*.json'):
    json.load(open(p))
print("schemas and templates OK")
EOF

node --check assets/juice.js
python3 -c "c=open('assets/base.css').read(); print('CSS balanced:', c.count('{')==c.count('}'))"

# if the Shopify CLI is installed
shopify theme check
shopify theme dev --store <your-store>.myshopify.com
```

## Git workflow

`main` tracks the live theme, `dev` tracks an unpublished preview theme.
Work on `dev`, preview in Shopify, merge to `main` to go live.
Shopify's GitHub integration syncs both directions, so **pull before you start**
— theme editor edits get committed back to the branch automatically.

`config/settings_data.json` is the file that will conflict, since the theme
editor writes to it. Uncomment the last line of `.gitignore` if that becomes
a problem.
